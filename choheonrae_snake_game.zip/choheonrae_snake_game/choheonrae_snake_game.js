let s;                                   //유저
let scl = 20;                            //뱀, 먹이 크기 설정
let food;                                //점수
let bomb;                                //폭탄

playfield = 600;                         //게임 맵 크기

function preload() {
  img=loadImage("https://raw.githubusercontent.com/joincheol/snake_game-team2/main/bomb.jpg");
}
function setup() {
  createCanvas(playfield, 640);
  background(51);
  s = new Snake();                       //객체 생성
  frameRate (10);                        //유저(뱀) 속도
  pickLocation();                        //시작점
}

function draw() {
  background(51);                       //맵의 배경 색
  scoreboard();                           //점수판 생성
  if (s.eat1(food)) {
    pickLocation();                       //먹이 위치 생성
  }
  s.death();
  s.update();
  s.show();

  fill (0,255,0);                         //점수(먹이) 색
  rect(food.x,food.y, scl, scl);            //점수(먹이) 모양
  
  fill(255,0,0)
  rect(bomb.x,bomb.y, scl, scl);
  image(img, bomb.x, bomb.y, scl, scl);
  if(s.eat2(bomb)){
    s.total = 0;
    s.score = 0;
    s.tail = [];
  }
}


function pickLocation() {                                
  let cols1 = floor(playfield/scl);                         //먹이의 위치 생성
  let rows1 = floor(playfield/scl);
  food = createVector(floor(random(cols1)), floor(random(rows1)));
  food.mult(scl);
    
  for (let i = 0; i < s.tail.length; i++) {
    let pos = s.tail[i];
    let d = dist(food.x, food.y, pos.x, pos.y);
    if (d < 1) {
      pickLocation();
    }
  }
  
  let cols2 = floor(playfield/scl);                        //폭탄의 위치 생성
  let rows2 = floor(playfield/scl);
  bomb = createVector(floor(random(cols2)), floor(random(rows2)));
  bomb.mult(scl);

  for (let i = 0; i < s.tail.length; i++) {
    let pos = s.tail[i];
    let d = dist(bomb.x, bomb.y, pos.x, pos.y);
    if (d < 1) {
      pickLocation();
    }
  }
}

function scoreboard() {
  fill(0);                                        //점수판의 색
  rect(0, 600, 600, 40);                     //점수판의 위치
  fill(255);                                     //점수 표시의 색
  textFont("Georgia");                       //점수 표시의 폰트
  textSize(18);                                //점수 표시의 사이즈
  text("Score: ", 10, 625);                  //점수 표시의 좌표 Score
  text("Highscore: ", 450, 625)            //점수 표시의 좌표 Highscore
  text(s.score, 70, 625);                     //현재 점수의 좌표
  text(s.highscore, 540, 625)               //현재 최고 점수의 좌표
}

function keyPressed() {                                       //조작법
  if (keyCode === UP_ARROW){
      s.dir(0, -1);
  }else if (keyCode === DOWN_ARROW) {
      s.dir(0, 1);
  }else if (keyCode === RIGHT_ARROW) {
      s.dir (1, 0);
  }else if (keyCode === LEFT_ARROW) {
      s.dir (-1, 0);
  }
}

function Snake() {
  this.x =0;
  this.y =0;
  this.xspeed = 1;
  this.yspeed = 0;
  this.total = 0;
  this.tail = [];
  this.score = 0;
  this.highscore = 0;

  this.dir = function(x,y) {
    this.xspeed = x;
    this.yspeed = y;
  }

  this.eat2 = function(pos) {
    let d = dist(this.x, this.y, pos.x, pos.y);
    if (d < 1) {    
      text(this.score, 70, 625);
      if (this.score > this.highscore) {
        this.highscore = this.score;
      }
      text(this.highscore, 540, 625);
      return true;
    } else {
      return false;
}
}
  
  this.eat1 = function(pos) {
    let d = dist(this.x, this.y, pos.x, pos.y);
    if (d < 1) {
      this.total++;
      this.score++;
      text(this.score, 70, 625);
      if (this.score > this.highscore) {
        this.highscore = this.score;
      }
      text(this.highscore, 540, 625);
      return true;
    } else {
      return false;
    }
  }

  this.death = function() {
    for (let i1 = 0; i1 < this.tail.length; i1++) {
      let pos = this.tail[i1];
      let d = dist(this.x, this.y, pos.x, pos.y);
      if (d < 1) {
        this.total = 0;
        this.score = 0;
        this.tail = [];
      }
    }
  }

  this.update = function(){
    if (this.total === this.tail.length) {
      for (let i = 0; i < this.tail.length-1; i++) {
        this.tail[i] = this.tail[i+1];
    }

    }
    this.tail[this.total-1] = createVector(this.x, this.y);

    this.x = this.x + this.xspeed*scl;
    this.y = this.y + this.yspeed*scl;

    this.x = constrain(this.x, 0, playfield-scl);
    this.y = constrain(this.y, 0, playfield-scl);


  }
  this.show = function(){                                        
    fill(255);
    for (let i = 0; i < this.tail.length; i++) {
        rect(this.tail[i].x, this.tail[i].y, scl, scl);
    }

    rect(this.x, this.y, scl, scl);
  }
}
