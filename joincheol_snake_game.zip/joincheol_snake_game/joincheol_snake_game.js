let s;
let scl = 20;
let food;
let img;
playfield = 600;

//먹이 값에 돈 이미지 생성
function preload() {
  img = loadImage("https://raw.githubusercontent.com/joincheol/snake_game-team2/main/prey.png");
}

function setup() {
  createCanvas(playfield, 640);
  background(51);
  s = new Snake(); //뱀 생성
  frameRate(10);
  pickLocation(); //먹이 위치 랜덤 생성
}

function draw() {
  //스코어가 1씩 증가할때마다 배경색 10씩 밝아지게 설정
  let num = s.score/3 * 10;
  background(51+num,51+num,51+num);
  scoreboard();

  //스코어가 1씩 증가할때마다 속도가증가
  let sF = s.score*1.0005;
  frameRate(10+sF);
  scoreboard();

  //뱀이 먹이먹으면 위치 랜덤 생성
  if (s.eat(food)) {
    pickLocation();
  }

  s.death(); //뱀이 죽었는지 확인
  s.update(); //뱀 위치 업데이트
  s.show(); //뱀 화면에 그리기

  //먹이 화면에 그리고 이미지 삽입
  rect(food.x, food.y, scl, scl);
  image(img, food.x, food.y, scl, scl);
}

//먹이 위치 랜덤 생성
function pickLocation() {
  let cols = floor(playfield / scl);
  let rows = floor(playfield / scl);
  food = createVector(floor(random(cols)), floor(random(rows)));
  food.mult(scl);

  for (let i = 0; i < s.tail.length; i++) {
    let pos = s.tail[i];
    let d = dist(food.x, food.y, pos.x, pos.y);
    if (d < 1) {
      pickLocation();
    }
  }
}

//점수판
function scoreboard() {
  fill(0);
  rect(0, 600, 600, 40);
  fill(255);
  textFont("Georgia");
  textSize(18);
  text("Score: ", 10, 625);
  text("Highscore: ", 450, 625);
  text(s.score, 70, 625);
  text(s.highscore, 540, 625);
}

//키보드 누름에 따른 위치 이동설정
function keyPressed() {
  if (keyCode === UP_ARROW) {
    s.dir(0, -1);
  } else if (keyCode === DOWN_ARROW) {
    s.dir(0, 1);
  } else if (keyCode === RIGHT_ARROW) {
    s.dir(1, 0);
  } else if (keyCode === LEFT_ARROW) {
    s.dir(-1, 0);
  }
}

//뱀 객체 생성 및 설정
function Snake() {
  this.x = 0;
  this.y = 0;
  this.xspeed = 1;
  this.yspeed = 0;
  this.total = 0;
  this.tail = [];
  this.score = 1;
  this.highscore = 1;

  //뱀의 이동방향 설정
  this.dir = function (x, y) {
    this.xspeed = x;
    this.yspeed = y;
  };

  //뱀이 먹이를 먹었을 꼬리 길이증가와 점수 증가
  this.eat = function (pos) {
    let d = dist(this.x, this.y, pos.x, pos.y);
    if (d < 1) {
      this.total++;
      this.score++;
      text(this.score, 70, 625);
      if (this.score > this.highscore) {
        this.highscore = this.score;
      }
      text(this.highscore, 540, 625);
      return true;
    } else {
      return false;
    }
  };

  //뱀이 죽었을때 초기화
  this.death = function () {
    for (let i = 0; i < this.tail.length; i++) {
      let pos = this.tail[i];
      let d = dist(this.x, this.y, pos.x, pos.y);

      if (d < 1) {
        this.total = 0;
        this.score = 0;
        this.tail = [];
      }
    }
  };

  //뱀의 음식 먹는거에 따른 머리와 꼬리 업데이트
  this.update = function () {
    if (this.total === this.tail.length) {
      for (let i = 0; i < this.tail.length - 1; i++) {
        this.tail[i] = this.tail[i + 1];
      }
    }
    this.tail[this.total - 1] = createVector(this.x, this.y);
    this.x = this.x + this.xspeed * scl;
    this.y = this.y + this.yspeed * scl;
    this.x = constrain(this.x, 0, playfield - scl);
    this.y = constrain(this.y, 0, playfield - scl);
  };

  this.show = function () {
    fill(255);
    for (let i = 0; i < this.tail.length; i++) {
      rect(this.tail[i].x, this.tail[i].y, scl, scl);
    }
    rect(this.x, this.y, scl, scl);
  };
}
